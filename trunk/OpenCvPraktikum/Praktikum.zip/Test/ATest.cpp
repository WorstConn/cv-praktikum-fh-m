/* 
 * File:   ATest.cpp
 * Author: Nils Frenking
 * 
 * Created on 21. Dezember 2012, 00:02
 */

#include "../header.h"

ATest::ATest() {
}

ATest::ATest(const ATest& orig) {
}

ATest::~ATest() {
}

