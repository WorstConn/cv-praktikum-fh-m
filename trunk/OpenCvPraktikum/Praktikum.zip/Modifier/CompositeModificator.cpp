/* 
 * File:   CompositeModificator.cpp
 * Author: Nils Frenking
 * 
 * Created on 20. Dezember 2012, 12:30
 */

#include "../header.h"

CompositeModificator::CompositeModificator() {
}

CompositeModificator::CompositeModificator(const CompositeModificator& orig) {
}

CompositeModificator::~CompositeModificator() {
}

