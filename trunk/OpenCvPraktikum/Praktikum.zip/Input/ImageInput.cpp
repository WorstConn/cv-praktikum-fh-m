/* 
 * File:   ImageInput.cpp
 * Author: Nils Frenking, Julian Cordes
 * 
 * Created on 29. November 2012, 18:57
 */

#include "../header.h"

ImageInput::ImageInput() {
}


ImageInput::~ImageInput() {
    
}

ImageInput::ImageInput(const ImageInput&){
    
}


